## Getting Started

Start the local database `npm run db:start`. In a separate terminal, seed the DB and run the server `npm run db:seed && npm run watch`.
